const {Client} = require('pg');
const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.get('/', (req, res) => {
  res.send('Lets go baby! Its heck time to rock,come on helloo!!!');
});


app.get('/health', (req, res) => {
  res.send('great!');
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});